/*
 * Led7Seg.h
 *
 *  Created on: Jan 19, 2020
 *      Author: asus
 */


#ifndef INC_LED7SEG_H_
#define INC_LED7SEG_H_

#include "stm32f1xx_hal.h"

class Led7Seg {
public:
	Led7Seg();
	virtual ~Led7Seg();

	void Num0() ;
	void Num1() ;
	void Num2() ;
	void Num3() ;
	void Num4() ;
	void Num5() ;
	void Num6() ;
	void Num7() ;
	void Num8() ;
	void Num9() ;

	void LedOff() ;
	void Display(unsigned int _Num) ;
};

class LedOject {
public :
	Led7Seg LedCol(int _Col) ;
};

#endif /* INC_LED7SEG_HP_ */
