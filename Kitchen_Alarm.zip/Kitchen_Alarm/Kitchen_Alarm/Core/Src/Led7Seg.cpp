/*
 * Led7Seg.cpp
 *
 *  Created on: Jan 19, 2020
 *      Author: asus
 */

#include <Led7Seg.h>

Led7Seg::Led7Seg() {
	// TODO Auto-generated constructor stub

}

Led7Seg::~Led7Seg() {
	// TODO Auto-generated destructor stub
}


void Led7Seg::Num0(){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)1 ) ;

}

void Led7Seg::Num1(){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)1 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)1 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)1 ) ;
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)1 ) ;
}

void Led7Seg::Num2(){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)1 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)0 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)1 ) ;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num3(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num4(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num5(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num6(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num7(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)1 ) ;
}

void Led7Seg::Num8(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void Led7Seg::Num9(){
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
}

void  Led7Seg::LedOff() {
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)1 ) ;
	  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)1 ) ;
}

void Led7Seg::Display(unsigned int _Num) {
	if(_Num > 9 || _Num < 0) {
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, (GPIO_PinState)0 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, (GPIO_PinState)1 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, (GPIO_PinState)1 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, (GPIO_PinState)0 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, (GPIO_PinState)0 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (GPIO_PinState)0 ) ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, (GPIO_PinState)0 ) ;
	}
	if(_Num == 0 ) Led7Seg::Num0() ;
	if(_Num == 1 ) Led7Seg::Num1() ;
	if(_Num == 2 ) Led7Seg::Num2() ;
	if(_Num == 3 ) Led7Seg::Num3() ;
	if(_Num == 4 ) Led7Seg::Num4() ;
	if(_Num == 5 ) Led7Seg::Num5() ;
	if(_Num == 6 ) Led7Seg::Num6() ;
	if(_Num == 7 ) Led7Seg::Num7() ;
	if(_Num == 8 ) Led7Seg::Num8() ;
	if(_Num == 9 ) Led7Seg::Num9() ;
}

Led7Seg LedOject::LedCol(int _Col) {
	if(_Col == 4) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)1 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, (GPIO_PinState)0 ) ;
	}
	if(_Col == 3) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)1 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, (GPIO_PinState)0 ) ;
	}
	if(_Col == 2) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, (GPIO_PinState)1 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, (GPIO_PinState)0 ) ;
	}
	if(_Col == 1) {
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, (GPIO_PinState)0 ) ;
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, (GPIO_PinState)1 ) ;
	}
}









